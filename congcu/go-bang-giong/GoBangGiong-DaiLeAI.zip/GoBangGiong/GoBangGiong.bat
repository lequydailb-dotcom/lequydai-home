@echo off
cd /d "%~dp0"
title GO BANG GIONG - DAI LE AI
if exist "python\python.exe" if exist "mo-hinh\sherpa-onnx-zipformer-vi-int8-2025-04-20\tokens.txt" if exist "python\Lib\site-packages\sherpa_onnx" goto chay
powershell -NoProfile -ExecutionPolicy Bypass -File "app\cai-lan-dau.ps1"
if errorlevel 1 goto loi
:chay
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
python\python.exe app\gobanggiong.py %*
echo.
echo Cong cu da dung. Bam phim bat ky de dong.
pause >nul
exit /b 0
:loi
echo.
echo Cai dat chua xong. Hay chup man hinh nay gui cho Dai Le tren Zalo.
pause
exit /b 1
