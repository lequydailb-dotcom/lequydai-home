@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "app\tu-khoi-dong.ps1" -Tat
pause
