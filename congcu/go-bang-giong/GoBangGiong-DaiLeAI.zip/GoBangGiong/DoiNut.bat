@echo off
cd /d "%~dp0"
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
if not exist "python\python.exe" (echo Hay chay file GoBangGiong.bat truoc de cai lan dau. & pause & exit /b 1)
python\python.exe app\gobanggiong.py --doi-nut
pause >nul
