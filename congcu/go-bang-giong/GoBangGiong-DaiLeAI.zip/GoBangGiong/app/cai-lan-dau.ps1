﻿# GÕ BẰNG GIỌNG - cài lần đầu. Không cần quyền quản trị, không đụng vào Python có sẵn trên máy.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ProgressPreference = 'SilentlyContinue'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

function Buoc($so, $chu) { Write-Host ""; Write-Host ("[{0}/4] {1}" -f $so, $chu) -ForegroundColor Cyan }
function Tai($url, $dich) {
    & curl.exe -L --fail --retry 3 --retry-delay 2 -# -o $dich $url
    if ($LASTEXITCODE -ne 0) { throw "Không tải được: $url" }
}

Write-Host "============================================================"
Write-Host " GÕ BẰNG GIỌNG - ĐẠI LÊ AI : cài đặt lần đầu (chỉ làm 1 lần)"
Write-Host " Cần mạng khoảng vài phút. Đừng đóng cửa sổ này."
Write-Host "============================================================"

try {
    $py = Join-Path $root 'python'
    $pyVer = '3.12.8'

    if (-not (Test-Path (Join-Path $py 'python.exe'))) {
        Buoc 1 "Tải bộ chạy Python riêng cho công cụ (khoảng 10 MB)..."
        $zip = Join-Path $root 'python-embed.zip'
        Tai "https://www.python.org/ftp/python/$pyVer/python-$pyVer-embed-amd64.zip" $zip
        if (Test-Path $py) { Remove-Item $py -Recurse -Force }
        Expand-Archive -Path $zip -DestinationPath $py -Force
        Remove-Item $zip -Force
        $pth = Get-ChildItem $py -Filter 'python*._pth' | Select-Object -First 1
        $noiDung = @("python312.zip", ".", "Lib\site-packages", "import site")
        Set-Content -Path $pth.FullName -Value $noiDung -Encoding ASCII
    } else { Write-Host "[1/4] Đã có bộ chạy Python, bỏ qua." }

    $pyExe = Join-Path $py 'python.exe'
    if (-not (Test-Path (Join-Path $py 'Lib\site-packages\pip'))) {
        Buoc 2 "Cài công cụ cài đặt (pip)..."
        $gp = Join-Path $root 'get-pip.py'
        Tai "https://bootstrap.pypa.io/get-pip.py" $gp
        & $pyExe $gp --no-warn-script-location
        if ($LASTEXITCODE -ne 0) { throw "Cài pip lỗi" }
        Remove-Item $gp -Force
    } else { Write-Host "[2/4] Đã có pip, bỏ qua." }

    if (-not (Test-Path (Join-Path $py 'Lib\site-packages\sherpa_onnx'))) {
        Buoc 3 "Cài các thư viện nhận giọng, micro, bắt phím (khoảng 40 MB)..."
        & $pyExe -m pip install --no-warn-script-location --disable-pip-version-check sherpa-onnx sounddevice pynput numpy soundfile
        if ($LASTEXITCODE -ne 0) { throw "Cài thư viện lỗi" }
    } else { Write-Host "[3/4] Đã có thư viện, bỏ qua." }

    $mh = Join-Path $root 'mo-hinh'
    $tenMh = 'sherpa-onnx-zipformer-vi-int8-2025-04-20'
    if (-not (Test-Path (Join-Path $mh "$tenMh\tokens.txt"))) {
        Buoc 4 "Tải bộ não nhận giọng tiếng Việt (khoảng 60 MB, chạy ngay trên máy bạn)..."
        New-Item -ItemType Directory -Force -Path $mh | Out-Null
        $nen = Join-Path $mh 'mo-hinh.tar.bz2'
        Tai "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/$tenMh.tar.bz2" $nen
        & tar.exe -xjf $nen -C $mh
        if ($LASTEXITCODE -ne 0) { throw "Giải nén mô hình lỗi" }
        Remove-Item $nen -Force
    } else { Write-Host "[4/4] Đã có mô hình, bỏ qua." }

    Write-Host ""
    Write-Host "Cài xong! Công cụ sẽ chạy ngay bây giờ." -ForegroundColor Green
    exit 0
}
catch {
    Write-Host ""
    Write-Host ("LỖI: " + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
