﻿param([switch]$Bat, [switch]$Tat)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$root = Split-Path -Parent $PSScriptRoot
$thuMuc = [Environment]::GetFolderPath('Startup')
$lnk = Join-Path $thuMuc 'GoBangGiong.lnk'
if ($Bat) {
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut($lnk)
    $sc.TargetPath = Join-Path $root 'GoBangGiong.bat'
    $sc.WorkingDirectory = $root
    $sc.WindowStyle = 7
    $sc.Save()
    Write-Host "Đã bật: GÕ BẰNG GIỌNG sẽ tự chạy mỗi khi mở máy (cửa sổ thu nhỏ sẵn)."
}
elseif ($Tat) {
    if (Test-Path $lnk) { Remove-Item $lnk -Force }
    Write-Host "Đã tắt tự chạy cùng máy."
}
