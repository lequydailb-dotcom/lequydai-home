# -*- coding: utf-8 -*-
"""
GÕ BẰNG GIỌNG - ĐẠI LÊ AI
Giữ một phím (hoặc nút chuột) để nói, thả ra là chữ tự gõ vào chỗ con trỏ.
Nhận giọng tiếng Việt ngay trên máy, không cần mạng, không cần tài khoản.
"""
import os
import sys
import re
import json
import time
import queue
import threading

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILE_CAI_DAT = os.path.join(BASE, "cai-dat.json")
TEN_MO_HINH = "sherpa-onnx-zipformer-vi-int8-2025-04-20"
THU_MUC_MH = os.path.join(BASE, "mo-hinh", TEN_MO_HINH)
TAN_SO = 16000
TOI_DA_GIAY = 60
THOI_GIAN_TOI_THIEU = 0.35

MAC_DINH = {
    "loai": None,          # "phim" hoặc "chuot"
    "ma": None,            # mã phím (số) hoặc "giua" / "x1" / "x2"
    "ten": None,           # tên hiển thị
    "che_do": "giu",       # "giu" = giữ để nói, "bat-tat" = bấm bật, bấm tắt
    "lenh_dau": True,      # nói "dấu phẩy", "dấu chấm", "xuống dòng"
    "them_dau_cham": False # tự thêm dấu chấm cuối câu
}

# ---------------------------------------------------------------- tiện ích


def in_(*a):
    try:
        print(*a, flush=True)
    except UnicodeEncodeError:
        print(*[str(x).encode("ascii", "replace").decode() for x in a], flush=True)


def la_windows():
    return os.name == "nt"


def keu_bip(tan_so, ms):
    if not la_windows():
        return

    def _b():
        try:
            import winsound
            winsound.Beep(tan_so, ms)
        except Exception:
            pass
    threading.Thread(target=_b, daemon=True).start()


# ------------------------------------------------------- chuẩn hoá chữ

LENH_DAU = [
    ("dấu chấm than", "!"),
    ("dấu hỏi chấm", "?"),
    ("dấu chấm hỏi", "?"),
    ("dấu hai chấm", ":"),
    ("dấu chấm phẩy", ";"),
    ("dấu chấm", "."),
    ("dấu phẩy", ","),
    ("dấu hỏi", "?"),
]


def chuan_hoa(van_ban, lenh_dau=True, them_dau_cham=False):
    """Mô hình trả chữ HOA, không dấu câu. Đổi thành câu viết bình thường."""
    t = (van_ban or "").strip().lower()
    if not t:
        return ""
    t = re.sub(r"\s+", " ", t)
    if lenh_dau:
        for cum, dau in LENH_DAU:
            t = t.replace(cum, " " + dau + " ")
        t = re.sub(r"\s*xuống dòng\s*", "\n", t)
        t = re.sub(r"[ \t]+([.,!?:;])", r"\1", t)
        t = re.sub(r"([.,!?:;])(?=[^\s.,!?:;\n])", r"\1 ", t)
        t = re.sub(r"[ \t]+\n", "\n", t)
        t = re.sub(r"\n[ \t]+", "\n", t)
        t = re.sub(r" {2,}", " ", t).strip()
    t = re.sub(
        r"(^|[.!?]\s+|\n)([^\W\d_])",
        lambda m: m.group(1) + m.group(2).upper(),
        t,
    )
    if them_dau_cham and t and t[-1].isalnum():
        t += "."
    return t


# ----------------------------------------------------------- nhận giọng


def tao_nhan_giong():
    import sherpa_onnx
    d = THU_MUC_MH
    return sherpa_onnx.OfflineRecognizer.from_transducer(
        encoder=os.path.join(d, "encoder-epoch-12-avg-8.int8.onnx"),
        decoder=os.path.join(d, "decoder-epoch-12-avg-8.onnx"),
        joiner=os.path.join(d, "joiner-epoch-12-avg-8.int8.onnx"),
        tokens=os.path.join(d, "tokens.txt"),
        num_threads=max(2, min(4, os.cpu_count() or 2)),
        sample_rate=TAN_SO,
        feature_dim=80,
        decoding_method="greedy_search",
    )


def nhan_giong(rec, audio):
    """audio: numpy float32, 16 kHz, 1 kênh. Trả về chữ HOA thô, hoặc None nếu im lặng."""
    import numpy as np
    if audio is None or len(audio) == 0:
        return None
    dinh = float(np.max(np.abs(audio)))
    if dinh < 0.004:
        return None
    if dinh < 0.5:
        audio = np.clip(audio * (0.7 / dinh), -1.0, 1.0).astype("float32")
    dem = np.zeros(int(0.2 * TAN_SO), dtype="float32")
    audio = np.concatenate([dem, audio, dem])
    s = rec.create_stream()
    s.accept_waveform(TAN_SO, audio)
    rec.decode_stream(s)
    return s.result.text


# --------------------------------------------------------------- ghi âm


class Ghi:
    def __init__(self):
        self.khung = []
        self.stream = None
        self.sr = TAN_SO
        self.kenh = 1

    def bat_dau(self):
        import sounddevice as sd
        self.khung = []

        def cb(indata, frames, thoi_gian, trang_thai):
            self.khung.append(indata.copy())

        thu = [(TAN_SO, 1)]
        try:
            sr_mac_dinh = int(sd.query_devices(kind="input")["default_samplerate"])
            thu += [(sr_mac_dinh, 1), (sr_mac_dinh, 2)]
        except Exception:
            pass
        loi = None
        for sr, kenh in thu:
            try:
                self.stream = sd.InputStream(
                    samplerate=sr, channels=kenh, dtype="float32", callback=cb
                )
                self.stream.start()
                self.sr, self.kenh = sr, kenh
                return True
            except Exception as e:  # thử cấu hình tiếp theo
                loi = e
                self.stream = None
        raise RuntimeError("Không mở được micro: %s" % loi)

    def dung(self):
        import numpy as np
        if self.stream is not None:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            self.stream = None
        if not self.khung:
            return np.zeros(0, dtype="float32")
        a = np.concatenate(self.khung, axis=0)
        a = a.mean(axis=1) if a.ndim == 2 else a
        a = a.astype("float32")
        if self.sr != TAN_SO and len(a) > 1:
            n = int(len(a) * TAN_SO / self.sr)
            a = np.interp(np.linspace(0, len(a) - 1, n), np.arange(len(a)), a).astype("float32")
        return a


# -------------------------------------------------- gõ chữ vào ô đang chọn


def _api_clipboard():
    import ctypes
    u32, k32 = ctypes.windll.user32, ctypes.windll.kernel32
    k32.GlobalAlloc.restype = ctypes.c_void_p
    k32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
    k32.GlobalLock.restype = ctypes.c_void_p
    k32.GlobalLock.argtypes = [ctypes.c_void_p]
    k32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    u32.OpenClipboard.argtypes = [ctypes.c_void_p]
    u32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
    u32.GetClipboardData.restype = ctypes.c_void_p
    u32.GetClipboardData.argtypes = [ctypes.c_uint]
    return ctypes, u32, k32


def _mo_clipboard(u32):
    for _ in range(20):
        if u32.OpenClipboard(None):
            return True
        time.sleep(0.03)
    return False


def lay_clipboard_chu():
    """Trả về chữ đang có trong clipboard, '' nếu trống, None nếu là thứ khác (ảnh, file...)."""
    try:
        ctypes, u32, k32 = _api_clipboard()
        if not u32.IsClipboardFormatAvailable(13):
            return "" if u32.CountClipboardFormats() == 0 else None
        if not _mo_clipboard(u32):
            return None
        try:
            h = u32.GetClipboardData(13)
            if not h:
                return ""
            p = k32.GlobalLock(h)
            if not p:
                return ""
            try:
                return ctypes.wstring_at(p)
            finally:
                k32.GlobalUnlock(h)
        finally:
            u32.CloseClipboard()
    except Exception:
        return None


def dat_clipboard_chu(text):
    try:
        ctypes, u32, k32 = _api_clipboard()
        du_lieu = (text + "\0").encode("utf-16-le")
        if not _mo_clipboard(u32):
            return False
        try:
            u32.EmptyClipboard()
            if text == "":
                return True
            h = k32.GlobalAlloc(0x0002, len(du_lieu))
            p = k32.GlobalLock(h)
            ctypes.memmove(p, du_lieu, len(du_lieu))
            k32.GlobalUnlock(h)
            u32.SetClipboardData(13, h)
            return True
        finally:
            u32.CloseClipboard()
    except Exception:
        return False


def go_chu(text, ban_phim):
    """Dán chữ vào chỗ con trỏ đang đứng. Dán bằng Ctrl+V cho nhanh và đúng dấu tiếng Việt."""
    from pynput.keyboard import Key
    cu = lay_clipboard_chu()
    if dat_clipboard_chu(text):
        time.sleep(0.06)
        with ban_phim.pressed(Key.ctrl):
            ban_phim.press("v")
            ban_phim.release("v")
        time.sleep(0.35)
        if cu is not None:
            dat_clipboard_chu(cu)
        return "dan"
    ban_phim.type(text)
    return "go"


# ---------------------------------------------------- phím / nút chuột

PHIM_CHO_PHEP = {}
for _i in range(1, 25):
    PHIM_CHO_PHEP[0x6F + _i] = "F%d" % _i
PHIM_CHO_PHEP.update({
    0x14: "Caps Lock",
    0x91: "Scroll Lock",
    0x13: "Pause",
    0x2D: "Insert",
    0xA3: "Ctrl bên phải",
})
CHUOT_CHO_PHEP = {
    "giua": "Nút giữa chuột (bấm bánh xe)",
    "x1": "Nút bên hông chuột (nút lùi)",
    "x2": "Nút bên hông chuột (nút tiến)",
}


def ten_hien_thi(cfg):
    if cfg.get("loai") == "phim":
        return PHIM_CHO_PHEP.get(cfg.get("ma"), str(cfg.get("ten")))
    return CHUOT_CHO_PHEP.get(cfg.get("ma"), str(cfg.get("ten")))


def tai_cai_dat():
    cfg = dict(MAC_DINH)
    try:
        with open(FILE_CAI_DAT, "r", encoding="utf-8") as f:
            cfg.update(json.load(f))
    except Exception:
        pass
    return cfg


def luu_cai_dat(cfg):
    with open(FILE_CAI_DAT, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def doc_nut_chuot(msg, data):
    """Trả (ten, la_nhan_xuong) nếu là nút chuột cho phép, ngược lại None."""
    if msg in (0x20B, 0x20C):
        nut = (data.mouseData >> 16) & 0xFFFF
        ten = {1: "x1", 2: "x2"}.get(nut)
        return (ten, msg == 0x20B) if ten else None
    if msg in (0x207, 0x208):
        return ("giua", msg == 0x207)
    return None


def chon_nut(cfg):
    """Cho người dùng bấm thử phím / nút chuột họ muốn dùng để nói."""
    from pynput import keyboard, mouse
    in_("")
    in_("=" * 60)
    in_(" CHỌN NÚT ĐỂ NÓI")
    in_("=" * 60)
    in_(" Hãy BẤM MỘT LẦN vào phím hoặc nút chuột bạn muốn dùng.")
    in_(" Gợi ý: F9, F8, Caps Lock, hoặc nút bên hông chuột.")
    in_(" (Không dùng chuột trái, chuột phải và các phím chữ.)")
    in_("")
    ket_qua = {}
    xong = threading.Event()

    def loc_phim(msg, data):
        if msg in (0x100, 0x104) and not (data.flags & 0x10):
            if data.vkCode in PHIM_CHO_PHEP:
                ket_qua.update({"loai": "phim", "ma": data.vkCode,
                                "ten": PHIM_CHO_PHEP[data.vkCode]})
                xong.set()
                lis_phim.suppress_event()
            else:
                in_(" -> Phím này không dùng được. Hãy chọn F1 đến F12, Caps Lock, "
                    "Pause, Insert hoặc nút chuột.")
        return True

    def loc_chuot(msg, data):
        r = doc_nut_chuot(msg, data)
        if r:
            ten, xuong = r
            if xuong:
                ket_qua.update({"loai": "chuot", "ma": ten, "ten": CHUOT_CHO_PHEP[ten]})
                xong.set()
                lis_chuot.suppress_event()
        return True

    lis_phim = keyboard.Listener(win32_event_filter=loc_phim)
    lis_chuot = mouse.Listener(win32_event_filter=loc_chuot)
    lis_phim.start()
    lis_chuot.start()
    xong.wait()
    time.sleep(0.4)
    lis_phim.stop()
    lis_chuot.stop()
    cfg.update(ket_qua)
    in_(" Đã chọn: %s" % ten_hien_thi(cfg))
    in_("")
    in_(" Cách nói:")
    in_("   1. GIỮ nút để nói, THẢ ra là chữ hiện (khuyên dùng)")
    in_("   2. BẤM một lần để bắt đầu, BẤM lần nữa để dừng")
    lua = ""
    while lua not in ("1", "2"):
        lua = input(" Chọn 1 hoặc 2 rồi bấm Enter: ").strip()
        if lua == "":
            lua = "1"
    cfg["che_do"] = "giu" if lua == "1" else "bat-tat"
    luu_cai_dat(cfg)
    in_(" Đã lưu cài đặt. Muốn đổi lại, chạy file DoiNut.bat")
    return cfg


# ---------------------------------------------------------- bộ điều khiển


class BoDieuKhien:
    """Nhận sự kiện bấm/thả từ phím hoặc chuột, ghi âm, nhận giọng, rồi gõ chữ."""

    def __init__(self, cfg, rec, ban_phim=None, ghi=None, dan=None):
        self.cfg = cfg
        self.rec = rec
        self.ban_phim = ban_phim
        self.ghi = ghi or Ghi()
        self.dan = dan or go_chu
        self.hang_su_kien = queue.Queue()
        self.hang_giong = queue.Queue()
        self.dang_ghi = False
        self.dang_giu = False
        self.bat_dau_luc = 0.0

    # gọi từ luồng bắt phím: chỉ bỏ vào hàng đợi, không làm gì nặng
    def nhan(self):
        if self.dang_giu:
            return
        self.dang_giu = True
        self.hang_su_kien.put("nhan")

    def tha(self):
        self.dang_giu = False
        self.hang_su_kien.put("tha")

    def chay(self):
        threading.Thread(target=self._vong_su_kien, daemon=True).start()
        threading.Thread(target=self._vong_giong, daemon=True).start()

    def _vong_su_kien(self):
        while True:
            try:
                ev = self.hang_su_kien.get(timeout=0.2)
            except queue.Empty:
                if self.dang_ghi and time.time() - self.bat_dau_luc > TOI_DA_GIAY:
                    in_(" (Đã nói quá %d giây, tự dừng để nhận giọng)" % TOI_DA_GIAY)
                    self._tat()
                continue
            try:
                if self.cfg["che_do"] == "giu":
                    if ev == "nhan":
                        self._bat()
                    elif ev == "tha" and self.dang_ghi:
                        self._tat()
                else:
                    if ev == "nhan":
                        self._tat() if self.dang_ghi else self._bat()
            except Exception as e:
                self.dang_ghi = False
                in_(" Lỗi micro: %s" % e)
                keu_bip(300, 300)

    def _bat(self):
        if self.dang_ghi:
            return
        self.ghi.bat_dau()
        self.dang_ghi = True
        self.bat_dau_luc = time.time()
        keu_bip(1000, 70)
        in_(" ● Đang nghe... (nói đi)")

    def _tat(self):
        if not self.dang_ghi:
            return
        self.dang_ghi = False
        audio = self.ghi.dung()
        keu_bip(600, 70)
        giay = len(audio) / float(TAN_SO)
        if giay < THOI_GIAN_TOI_THIEU:
            in_(" (Nói quá ngắn, bỏ qua)")
            return
        self.hang_giong.put(audio)

    def _vong_giong(self):
        while True:
            audio = self.hang_giong.get()
            try:
                t0 = time.time()
                tho = nhan_giong(self.rec, audio)
                if tho is None:
                    in_(" Không nghe thấy tiếng. Kiểm tra micro nhé.")
                    keu_bip(300, 200)
                    continue
                chu = chuan_hoa(tho, self.cfg.get("lenh_dau", True),
                                self.cfg.get("them_dau_cham", False))
                if not chu:
                    in_(" Không nhận ra chữ nào.")
                    continue
                in_(" ✓ %s   (%.1f giây)" % (chu.replace("\n", " ⏎ "), time.time() - t0))
                self.dan(chu, self.ban_phim)
            except Exception as e:
                in_(" Lỗi khi nhận giọng: %s" % e)


# ------------------------------------------------------------------ chạy


def tim_loi_thieu():
    if not os.path.isfile(os.path.join(THU_MUC_MH, "tokens.txt")):
        return "Chưa có mô hình nhận giọng. Hãy chạy GoBangGiong.bat để cài lần đầu."
    return None


def chay_chinh(cfg):
    from pynput import keyboard, mouse
    in_(" Đang tải mô hình nhận giọng (vài giây)...")
    rec = tao_nhan_giong()
    ban_phim = keyboard.Controller()
    bdk = BoDieuKhien(cfg, rec, ban_phim)
    bdk.chay()

    ma = cfg["ma"]

    if cfg["loai"] == "phim":
        def loc_phim(msg, data):
            try:
                if data.vkCode == ma and not (data.flags & 0x10):
                    if msg in (0x100, 0x104):
                        bdk.nhan()
                    elif msg in (0x101, 0x105):
                        bdk.tha()
                    ghi_nho["phim"].suppress_event()
            except AttributeError:
                pass
            return True
        ghi_nho = {}
        ghi_nho["phim"] = keyboard.Listener(win32_event_filter=loc_phim)
        ghi_nho["phim"].start()
        lis = [ghi_nho["phim"]]
    else:
        def loc_chuot(msg, data):
            try:
                r = doc_nut_chuot(msg, data)
                if r and r[0] == ma:
                    bdk.nhan() if r[1] else bdk.tha()
                    ghi_nho["chuot"].suppress_event()
            except AttributeError:
                pass
            return True
        ghi_nho = {}
        ghi_nho["chuot"] = mouse.Listener(win32_event_filter=loc_chuot)
        ghi_nho["chuot"].start()
        lis = [ghi_nho["chuot"]]

    in_("")
    in_("=" * 60)
    in_(" GÕ BẰNG GIỌNG - ĐẠI LÊ AI   (đang chạy)")
    in_("=" * 60)
    if cfg["che_do"] == "giu":
        in_(" Nút nói : %s" % ten_hien_thi(cfg))
        in_(" Cách dùng: bấm chuột vào ô muốn gõ chữ, GIỮ nút, nghe tiếng 'bip' rồi nói,")
        in_("            THẢ nút ra. Chữ tự hiện ngay chỗ con trỏ.")
    else:
        in_(" Nút nói : %s" % ten_hien_thi(cfg))
        in_(" Cách dùng: bấm chuột vào ô muốn gõ chữ, BẤM nút một lần rồi nói,")
        in_("            BẤM nút lần nữa để dừng. Chữ tự hiện ngay chỗ con trỏ.")
    in_(" Mẹo: nói 'dấu phẩy', 'dấu chấm', 'xuống dòng' để ngắt câu.")
    in_(" Thu nhỏ cửa sổ này xuống thanh dưới là được. Đóng cửa sổ = tắt công cụ.")
    in_("=" * 60)
    keu_bip(800, 60)
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    for l in lis:
        l.stop()


def thu_file(duong_dan):
    import soundfile as sf
    rec = tao_nhan_giong()
    a, sr = sf.read(duong_dan, dtype="float32")
    if a.ndim > 1:
        a = a.mean(axis=1)
    if sr != TAN_SO:
        import numpy as np
        n = int(len(a) * TAN_SO / sr)
        a = np.interp(np.linspace(0, len(a) - 1, n), np.arange(len(a)), a).astype("float32")
    tho = nhan_giong(rec, a)
    in_("THO : %s" % tho)
    in_("CHUAN: %s" % chuan_hoa(tho or ""))


def thu_dan():
    from pynput import keyboard
    in_("Bấm chuột vào ô soạn thảo (ví dụ Notepad). 6 giây nữa sẽ gõ thử...")
    time.sleep(6)
    kq = go_chu("Xin chào, đây là thử nghiệm GÕ BẰNG GIỌNG. Tiếng Việt có dấu.", keyboard.Controller())
    in_("Đã gõ bằng cách: %s" % kq)


def main():
    args = sys.argv[1:]
    if "--thu-file" in args:
        thu_file(args[args.index("--thu-file") + 1])
        return
    if "--thu-dan" in args:
        thu_dan()
        return
    loi = tim_loi_thieu()
    if loi:
        in_(loi)
        return 1
    cfg = tai_cai_dat()
    if "--doi-nut" in args or not cfg.get("loai"):
        cfg = chon_nut(cfg)
    chay_chinh(cfg)
    return 0


if __name__ == "__main__":
    sys.exit(main() or 0)
